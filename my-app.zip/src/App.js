
import './App.css';
import Assignment1 from './assignment_1/AllRoutes/Assignment1';
import Assignment2 from './assignment_2/Assignment2';
import Assignment3 from './assignment_3/Assignment3';


function App() {
  return (
    <div className="App">
       {/* <Assignment1/> */}
       {/* <Assignment2/> */}
       <Assignment3/>
    </div>
  );
}

export default App;
